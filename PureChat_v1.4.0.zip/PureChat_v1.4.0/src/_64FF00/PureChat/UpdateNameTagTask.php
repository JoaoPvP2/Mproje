<?php

namespace _64FF00\PureChat;

use pocketmine\scheduler\Task;

class UpdateNameTagTask extends Task
{
    private $plugin;
    private $chatListener;

    public function __construct(PureChat $plugin, ChatListener $chatListener)
    {
        $this->plugin = $plugin;
        $this->chatListener = $chatListener;
    }

    public function onRun($currentTick)
{
    foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
        $this->chatListener->updatePlayerInformation($player);
        }
    }
}

