<?php

namespace _64FF00\PureChat;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;

class PureChat extends PluginBase
{
    private $purePerms;
    private $factionsPro;
    private $ru;

    public function onLoad()
    {
        $this->saveDefaultConfig();

        if ($this->getConfig()->getNested("enable-multiworld-support")) {
            $this->getLogger()->notice("Successfully enabled PureChat multiworld support");
        }
    }

    public function onEnable()
{
    $this->purePerms = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
    $this->factionsPro = $this->getServer()->getPluginManager()->getPlugin("FactionsPro");
    $this->ru = $this->getServer()->getPluginManager()->getPlugin("RankUp");

    // Crie a instância do ChatListener
    $this->chatListener = new ChatListener($this);
    $this->getServer()->getPluginManager()->registerEvents($this->chatListener, $this);

    // Agende a tarefa para atualizar as nametags
    $this->getServer()->getScheduler()->scheduleRepeatingTask(new UpdateNameTagTask($this, $this->chatListener), 20); // 20 ticks = 1 segundo
}

    public function addColors(string $string): string
    {
        $string = str_replace("{COLOR_BLACK}", TextFormat::BLACK, $string);
        $string = str_replace("{COLOR_DARK_BLUE}", TextFormat::DARK_BLUE, $string);
        $string = str_replace("{COLOR_DARK_GREEN}", TextFormat::DARK_GREEN, $string);
        $string = str_replace("{COLOR_DARK_AQUA}", TextFormat::DARK_AQUA, $string);
        $string = str_replace("{COLOR_DARK_RED}", TextFormat::DARK_RED, $string);
        $string = str_replace("{COLOR_DARK_PURPLE}", TextFormat::DARK_PURPLE, $string);
        $string = str_replace("{COLOR_GOLD}", TextFormat::GOLD, $string);
        $string = str_replace("{COLOR_GRAY}", TextFormat::GRAY, $string);
        $string = str_replace("{COLOR_DARK_GRAY}", TextFormat::DARK_GRAY, $string);
        $string = str_replace("{COLOR_BLUE}", TextFormat::BLUE, $string);
        $string = str_replace("{COLOR_GREEN}", TextFormat::GREEN, $string);
        $string = str_replace("{COLOR_AQUA}", TextFormat::AQUA, $string);
        $string = str_replace("{COLOR_RED}", TextFormat::RED, $string);
        $string = str_replace("{COLOR_LIGHT_PURPLE}", TextFormat::LIGHT_PURPLE, $string);
        $string = str_replace("{COLOR_YELLOW}", TextFormat::YELLOW, $string);
        $string = str_replace("{COLOR_WHITE}", TextFormat::WHITE, $string);

        $string = str_replace("{FORMAT_OBFUSCATED}", TextFormat::OBFUSCATED, $string);
        $string = str_replace("{FORMAT_BOLD}", TextFormat::BOLD, $string);
        $string = str_replace("{FORMAT_STRIKETHROUGH}", TextFormat::STRIKETHROUGH, $string);
        $string = str_replace("{FORMAT_UNDERLINE}", TextFormat::UNDERLINE, $string);
        $string = str_replace("{FORMAT_ITALIC}", TextFormat::ITALIC, $string);
        $string = str_replace("{FORMAT_RESET}", TextFormat::RESET, $string);

        return $string;
    }

    public function removeColors(string $string): string
    {
        $colors = [
            TextFormat::BLACK, TextFormat::DARK_BLUE, TextFormat::DARK_GREEN,
            TextFormat::DARK_AQUA, TextFormat::DARK_RED, TextFormat::DARK_PURPLE,
            TextFormat::GOLD, TextFormat::GRAY, TextFormat::DARK_GRAY,
            TextFormat::BLUE, TextFormat::GREEN, TextFormat::AQUA,
            TextFormat::RED, TextFormat::LIGHT_PURPLE, TextFormat::YELLOW,
            TextFormat::WHITE, TextFormat::OBFUSCATED, TextFormat::BOLD,
            TextFormat::STRIKETHROUGH, TextFormat::UNDERLINE, TextFormat::ITALIC,
            TextFormat::RESET
        ];

        foreach ($colors as $color) {
            $string = str_replace($color, '', $string);
        }

        return $string;
    }

    public function getNameTag(Player $player, $levelName = null)
{
    $group = $this->purePerms->getUserDataMgr()->getGroup($player, $levelName);
    $groupName = $group->getName();

    if ($levelName === null) {
        if ($this->getConfig()->getNested("groups.$groupName.default-nametag") === null) {
            $this->getConfig()->setNested("groups.$groupName.default-nametag", "[$groupName] {display_name}");
        }
        $nameTag = $this->getConfig()->getNested("groups.$groupName.default-nametag");
    } else {
        if ($this->getConfig()->getNested("groups.$groupName.worlds.$levelName.default-nametag") === null) {
            $this->getConfig()->setNested("groups.$groupName.worlds.$levelName.default-nametag", "[$groupName] {display_name}");
            $this->getConfig()->save();
        }
        $nameTag = $this->getConfig()->getNested("groups.$groupName.worlds.$levelName.default-nametag");
    }

    if ($this->factionsPro !== null) {
        if ($this->getConfig()->getNested("custom-no-fac-message") === null) {
            $this->getConfig()->setNested("custom-no-fac-message", "...");
            $this->saveConfig();
        }

        if (!$this->factionsPro->isInFaction($player->getName())) {
            $nameTag = str_replace("{faction}", $this->getConfig()->getNested("custom-no-fac-message"), $nameTag);
        } elseif ($this->factionsPro->isLeader($player->getName())) {
            $nameTag = str_replace("{faction}", "**" . $this->factionsPro->getPlayerFaction($player->getName()), $nameTag);
        } elseif ($this->factionsPro->isOfficer($player->getName())) {
            $nameTag = str_replace("{faction}", "*" . $this->factionsPro->getPlayerFaction($player->getName()), $nameTag);
        } else {
            $nameTag = str_replace("{faction}", "" . $this->factionsPro->getPlayerFaction($player->getName()), $nameTag);
        }
    }

    $nameTag = str_replace("{world_name}", $levelName, $nameTag);
    $nameTag = str_replace("{display_name}", $player->getDisplayName(), $nameTag);
    $nameTag = str_replace("{user_name}", $player->getName(), $nameTag);
    $nameTag = str_replace("{rank}", $this->ru->getPermManager()->getGroup($player), $nameTag);

    // Adicionar vida e ping na NameTag
    $vida = round($player->getHealth());
    $ping = $player->getPing();
    $vidaTag = "§7{$vida}§cHP";
    $pingTag = "§7{$ping}§ams";
    $nameTag .= " \n$vidaTag | $pingTag";

    $nameTag = $this->addColors($nameTag);

    if (!$player->hasPermission("pchat.colored.nametag")) {
        $nameTag = $this->removeColors($nameTag);
    }

    return $nameTag;
}

public function getCustomChatFormat(Player $player, $message, $levelName = null)
{
    $rankUp = $this->ru->getPermManager()->getGroup($player);
    $group = $this->purePerms->getUserDataMgr()->getGroup($player, $levelName);
    $groupName = $group->getName();

    if ($levelName === null) {
        if ($this->getConfig()->getNested("groups.$groupName.default-chat") === null) {
            $this->getConfig()->setNested("groups.$groupName.default-chat", "[$groupName] {display_name} > {message}");
            $this->saveConfig();
        }
        $chatFormat = $this->getConfig()->getNested("groups.$groupName.default-chat");
    } else {
        if ($this->getConfig()->getNested("groups.$groupName.worlds.$levelName.default-chat") === null) {
            $this->getConfig()->setNested("groups.$groupName.worlds.$levelName.default-chat", "[$groupName] {display_name} > {message}");
            $this->saveConfig();
        }
        $chatFormat = $this->getConfig()->getNested("groups.$groupName.worlds.$levelName.default-chat");
    }

    if ($this->factionsPro !== null) {
        if ($this->getConfig()->getNested("custom-no-fac-message") === null) {
            $this->getConfig()->setNested("custom-no-fac-message", "...");
            $this->saveConfig();
        }

        if (!$this->factionsPro->isInFaction($player->getName())) {
            $chatFormat = str_replace("{faction}", $this->getConfig()->getNested("custom-no-fac-message"), $chatFormat);
        } elseif ($this->factionsPro->isLeader($player->getName())) {
            $chatFormat = str_replace("{faction}", "**" . $this->factionsPro->getPlayerFaction($player->getName()), $chatFormat);
        } elseif ($this->factionsPro->isOfficer($player->getName())) {
            $chatFormat = str_replace("{faction}", "*" . $this->factionsPro->getPlayerFaction($player->getName()), $chatFormat);
        } else {
            $chatFormat = str_replace("{faction}", "" . $this->factionsPro->getPlayerFaction($player->getName()), $chatFormat);
        }
    }

    $chatFormat = str_replace("{world_name}", $levelName, $chatFormat);
    $chatFormat = str_replace("{display_name}", $player->getDisplayName(), $chatFormat);
    $chatFormat = str_replace("{user_name}", $player->getName(), $chatFormat);
    $chatFormat = str_replace("{rank_player}", $rankUp, $chatFormat);

    $chatFormat = $this->addColors($chatFormat);

    if (!$player->hasPermission("pchat.colored.format")) {
        $chatFormat = $this->removeColors($chatFormat);
    }

    $message = $this->addColors($message);

    if (!$player->hasPermission("pchat.colored.chat")) {
        $message = $this->removeColors($message);
    }

    $chatFormat = str_replace("{message}", $message, $chatFormat);

    return $chatFormat;
    }
}

